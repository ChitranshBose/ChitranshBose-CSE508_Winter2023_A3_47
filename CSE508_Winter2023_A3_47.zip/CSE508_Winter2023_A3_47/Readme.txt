Ques 1. 
1. Upload the notebook in colab.
2. Execute the cells sequentially.
3. A .txt file of the dataset should be extracted in the current working directory.

Ques 2. 
1. Upload the notebook in colab.
2. Execute the cells sequentially.
3. A .txt file of the dataset should be extracted in the current working directory.
